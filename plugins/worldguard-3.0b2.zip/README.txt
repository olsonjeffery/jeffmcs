WorldGuard
Copyright (c) 2010, 2011 sk89q <http://www.sk89q.com>
Licensed under the GNU Lesser General Public License v3

Introduction
------------

WorldGuard protects your server!

Documentation can be found at:
http://wiki.sk89q.com/wiki/WorldGuard

Thanks
------

While I would like to thank everyone for their support, I would like to
say thanks to the following individuals for their direct
contributions to WorldGuard:

- Sturmeh, for contributing the original durability workaround
- Meaglin, for changing the on flow hook at my request
- Dinnerbone, for implementing the on item pick up hook at my request,
    and also for figuring out the durability bug in the process
